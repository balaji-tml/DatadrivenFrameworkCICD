package com.bit.utilities;

public class Constants {

    public static String SUITE1_XL_PATH = System.getProperty("user.dir") +
            "/src/test/resources/excel/SwagLabSuite.xlsx";
    public static String DATA_SHEET = "TestData";
}
